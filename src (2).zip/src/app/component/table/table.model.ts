export class EmployeeModel{
  id : number = 0;
  sapId : string = '';

  text : string = '';
  email : string = '';
  gender : string = '';
  contact : number = 0;
  rm : string = '';
  // items: [] = [];
  // location: string = '';
  // role: string = '';
  // designation: string = '';
  // employeeStatus: string = '';
  // image: string = ''
}
