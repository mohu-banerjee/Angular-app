export interface employeeDatas {
  id: number;
  text: string;
  image: string;
  contact: number;
  designation:string;
  email:string;
  gender: string;
  sapId: number;
  role: string;
  location: string;
  rm: string;
  employeeStatus: string

}
