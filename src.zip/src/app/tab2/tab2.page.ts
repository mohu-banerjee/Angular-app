import { Component } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ToastController } from '@ionic/angular';
import { ModalController } from '@ionic/angular';
import { MenuController } from '@ionic/angular';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {

  constructor(public toastController: ToastController, public modalCtrl: ModalController, private menu: MenuController) {}

  userName = "some_guy_named_ravindra"
  displayName = "Ravindra Kumar"
  bio = "Innovative and ambitious Application developer with 2.5+ years of experience having skillful expertise in Web Development using UI technologies ReactJs , VueJs and design Frameworks like Bootstrap & CSS."
  profession="Lead Engineer"
  location="India"

  filterTerm: string

  followers = [
    {name:"Connor Smith", position: "Sales Rep", photo:"https://i.pravatar.cc/300?u=a"},
    {name:"Daniel Smith", position: "Product Designer", photo:"https://i.pravatar.cc/300?u=b"},
    {name:"Greg Smith", position: "Director of Operations", photo:"https://i.pravatar.cc/300?u=c"},
    {name:"Zoey Smith", position: "CEO", photo:"https://i.pravatar.cc/300?u=d"},
    {name:"Will Smith", position: "CFO", photo:"https://i.pravatar.cc/300?u=e"},
  ]

  myPosts:any[] = [];
  postForm = new FormGroup({
    title: new FormControl(''),
    body: new FormControl('')
  });

  onPostSubmit(){

    let postObject: any = {}
    postObject.title = this.postForm.value.title!;
    postObject.body = this.postForm.value.body!;

    this.myPosts.push(postObject);
    this.presentToast();

    this.postForm = new FormGroup({
      title: new FormControl(''),
      body: new FormControl('')
    });

    this.modalCtrl.dismiss();

    

  }

  allData:any =  []
  filterData:any = []

  ionViewDidEnter(){
    this.allData = this.followers;
    this.filterData = this.allData;
  }

  setFilteredData(){
    this.filterData = this.allData.filter((data) => {
      return data.name.toLowerCase().indexOf(this.filterTerm.toLowerCase()) > -1;
    });
  }

  handlePositionChange(e){
    this.presentToast();
  }
  

  async presentToast() {
    const toast = await this.toastController.create({
      message: 'Data Saved Succesfully.',
      duration: 2000,
      color: 'success',
    });
    toast.present();
  }


  openFirst() {
    this.menu.enable(true, 'first');
    this.menu.open('first');
  }

  openEnd() {
    this.menu.open('end');
  }

  openCustom() {
    this.menu.enable(true, 'custom');
    this.menu.open('custom');
  }



}
